-- =====================================================================
-- Athena Validation Checks (Row Counts + Integrity)
-- Purpose:
--   Provide a compact, repeatable set of verification queries that confirm
--   each pipeline stage produces the expected shape and referential integrity.
--
-- Usage:
--   Run these after each Glue job completes (and after any reprocessing).
-- =====================================================================

-- ---------------------------------------------------------------------
-- Accelerometer Trusted: Row count check
-- (Rubric reference for the standard dataset is commonly ~40,981)
-- ---------------------------------------------------------------------
SELECT COUNT(*) AS cnt
FROM stedi_db.accelerometer_trusted;

-- Optional spot check (sample rows)
SELECT *
FROM stedi_db.accelerometer_trusted
LIMIT 10;


-- ---------------------------------------------------------------------
-- Customer Curated: Row count check
-- (Rubric reference for the standard dataset is commonly 482)
-- ---------------------------------------------------------------------
SELECT COUNT(*) AS customer_curated_count
FROM stedi_db.customer_curated;

-- Integrity: curated customers must have accelerometer data (expected: 0)
SELECT COUNT(*) AS curated_without_accel
FROM stedi_db.customer_curated c
LEFT JOIN stedi_db.accelerometer_trusted a
  ON lower(c.email) = lower(a.user)
WHERE a.user IS NULL;

-- Optional spot check
SELECT *
FROM stedi_db.customer_curated
LIMIT 25;


-- ---------------------------------------------------------------------
-- Step Trainer Trusted: Row count check
-- (Rubric reference for the standard dataset is commonly ~14,460)
-- ---------------------------------------------------------------------
SELECT COUNT(*) AS step_trainer_trusted_count
FROM stedi_db.step_trainer_trusted;

-- Integrity: every step row must map to a curated serialNumber (expected: 0)
SELECT COUNT(*) AS orphan_step_rows
FROM stedi_db.step_trainer_trusted s
LEFT JOIN stedi_db.customer_curated c
  ON lower(s.serialnumber) = lower(c.serialnumber)
WHERE c.serialnumber IS NULL;


-- ---------------------------------------------------------------------
-- Machine Learning Curated: Row count check
-- (Rubric reference for the standard dataset is commonly ~43,681)
-- ---------------------------------------------------------------------
SELECT COUNT(*) AS row_count
FROM stedi_db.machine_learning_curated;

-- Optional spot check
SELECT *
FROM stedi_db.machine_learning_curated
LIMIT 25;
